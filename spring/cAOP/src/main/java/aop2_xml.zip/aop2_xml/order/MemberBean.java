package aop2_xml.order;

public interface MemberBean {
    void register();
    boolean update(String name);
}
